# Whack‑a‑Square

A tiny JavaScript whack‑a‑mole style game. Just open index.html or publish via GitHub Pages.